package com.example.app.domain.common.dao;



public interface DaoFunctionHeaderNaming {
	
		public boolean select(Object object);
		public boolean selectAll();
		public boolean insert(Object object);
		public boolean update(Object object);
		public boolean delete(Object object);
}
